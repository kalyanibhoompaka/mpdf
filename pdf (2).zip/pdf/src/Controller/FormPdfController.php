<?php
namespace Drupal\pdf\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\node\Entity\Node;
use \Mpdf\Mpdf;
use Drupal\Core\StreamWrapper\PublicStream;
use Drupal\Core\Render\Markup;
use Drupal\Core\File\FileSystemInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\taxonomy\Entity\Term;
use Drupal\file\Entity\File;

class FormPdfController extends ControllerBase {
    public function view_data($nid) {
//dd($nid);
$node=Node::load($nid);
$paragraphs = $node->field_books->referencedEntities();
$countrys = $node->field_country->referencedEntities();
$title=$node->get('title')->value;
//dd($title);

  foreach ( $paragraphs as $paragraph ) {
    $authorname = $paragraph->get('field_author_name')->getValue()[0]['value'];
    $title = $paragraph->get('field_book_title')->getValue()[0]['value'];
    $description	 = $paragraph->get('field_description')->getValue()[0]['value'];
    $editorname = $paragraph->get('field_editor_name')->getValue()[0]['value'];
    $isbnnumber = $paragraph->get('field_isbn_number')->getValue()[0]['value'];
    $file = $paragraph->get('field_file')->getValue();


  }
  foreach ( $countrys as $country ) {
    $country_name = $country->get('field_country_name')->getValue()[0]['value'];
    $address = $country->get('field_address')->getValue()[0]['value'];
    $phone = $country->get('field_phone')->getValue()[0]['value'];
    $pincode = $country->get('field_pincode')->getValue()[0]['value'];
    $city = $country->get('field_city')->getValue()[0]['value'];  }
  


$table='<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>Library Details</h2>

<table>
<title>Country Details</title>

  <tr>
  <th>Country</th>
    <th>Address</th>
    <th>Phone number</th>
    <th>Pincode</th>
    <th>city</th>

  </tr>

  <tr>
  <td>'.$country_name.'</td>
    <td>'.$address.'</td>
   <td>'.$phone.'</td>
   <td>'.$pincode.'</td>
   <td>'.$city.'</td>

</table>

<br/>
<br/>
<br/>
<table>
<title>Book Details</title>
  <tr>
    <th>Book title</th>
    <th>Authorname</th>
    <th>Description</th>
    <th>Editorname</th>
    <th>isbnnumber</th>
    <th>file</th>
  </tr>

  <tr>
  <td>'.$title.'</td>
    <td>'.$authorname.'</td>
    <td>'.$description.'</td>
   <td>'.$editorname.'</td>
   <td>'.$isbnnumber.'</td>
   <td>'.$file.'</td>

</table>

</body>
</html>

';



  

 // Call the mail template
 $templatee = [


  
  '#id' => 1,
    '#theme' => 'timetempl',
    '#country_name' => $country_name,
    '#address' => $address,
    '#phone' => $phone,
    '#city' => $city,
    '#title' => $title,
    '#authorname' => $authorname,
    '#description' => $description,
    '#editorname' => $editorname,
    '#isbnnumber' => $isbnnumber,
    '#file' => $file,

    '#pincode' => $pincode,

];
// Render the template
$rendered_template = \Drupal::service('renderer')->renderPlain($templatee);

$html = 'this is my <b>first</b>downloadable pdf';
$mpdf = new \Mpdf\Mpdf(['tempDir' => 'sites/default/files/tmp']); $mpdf->WriteHTML($rendered_template);
$mpdf->Output('file.pdf', 'D');
return $templatee;
  }

  
}